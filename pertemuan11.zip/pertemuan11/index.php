<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Pertemuan-11</title>
</head>
<body>
    <h1>Tugas Pemrograman Web Pertemuan 11</h1>
    <div class="container1">
        <div class="container2">
            <ul>
                <a href="index.php">Home</a>
                <a href="entri.php">Entri</a>
                <a href="update.php">Update</a>
                <a href="laporan.php">Laporan</a>
            </ul>
        </div>
    </div>
    <div>
        <p>Kelompok yang diketuai oleh <b>Gunawan Wibisono.</b></p>
        <p>Daftar nama anggota :</p>
        <ul>
            <li>Anri Daniata Purba</li>
            <li>Arisky</li>
            <li>Candra Bamel Harahap</li>
            <li>Gunawan</li>
            <li>Nepla Bima Putra</li>
        </ul>
    </div>
</body>
</html>